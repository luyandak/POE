﻿using System.Collections.Generic;
using System.Windows;
using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Recipe_application_final
{
    
    public partial class MainWindow : Window
    {
        //declaration of all lists that will be used to store user data for recipes.
        private List<int> calorieslist = new List<int>();
        private int ingredientsNum;
        private List<string> nameIngrList = new List<string>();
        private List<int> quantityIngredientsList = new List<int>();
        private List<string> unitOfMeasurementList = new List<string>();
        private List<string> stepsList = new List<string>();
        private List<int> quantityIngredientstwo;
        private List<string> nameRecipeList = new List<string>();
        private List<string> foodgroupList = new List<string>();
        private int caloriessum; //declaration of variable that will store sum of calories
        private int ingredientCalories; //declaration of variable that stores the ingredients calories

        public MainWindow()
        {
            InitializeComponent(); 
        }

        private void MainForm_Load(object sender, EventArgs e)
        {

           //name of Recipe apllication(naming the form)
            this.Title = "Recipe Application";
        }

        private void UserInputButton_Click(object sender, RoutedEventArgs e)
        {
            // Handles the user input and performs calories calculation.

            //Gets the number of ingredients from the user
            if (!int.TryParse(ingredientsNumTextBox.Text, out ingredientsNum) || ingredientsNum <= 0)
            {//error handling for when user input is invalid.
                MessageBox.Show("Invalid input. Please enter a valid integer greater than 0.");
                return;
            }

            // Retrieves ingredient details from the user for the specified number of ingredients
            for (int i = 0; i < ingredientsNum; i++)
            {
                 
                string ingredientName = Microsoft.VisualBasic.Interaction.InputBox("Enter Ingredient name:");
                nameIngrList.Add(ingredientName);

                int quantity;
                if (!int.TryParse(Microsoft.VisualBasic.Interaction.InputBox("Enter the quantity used:"), out quantity) || quantity <= 0)
                {//error handling for when user input is invalid.
                    MessageBox.Show("Invalid input. Please enter a valid integer greater than 0.");
                    return;
                }
                quantityIngredientsList.Add(quantity);

                string unitOfMeasurement = Microsoft.VisualBasic.Interaction.InputBox("Enter the unit of measurement that will be used:");
                unitOfMeasurementList.Add(unitOfMeasurement);

                string foodGroup = Microsoft.VisualBasic.Interaction.InputBox("Enter the number of the food group the ingredient belongs to (1-7):");
                foodgroupList.Add(foodGroup);

                int calories;
                if (!int.TryParse(Microsoft.VisualBasic.Interaction.InputBox($"Enter amount of calories contained by the ingredient {i + 1}:"), out calories) || calories <= 0)
                {
                    MessageBox.Show("Invalid input. Please enter a valid integer greater than 0.");
                    return;
                }
                calorieslist.Add(calories);
            }

            int totalCalories = TotalCaloriesCalculation(calorieslist);

            if (totalCalories > 300)
            {
                CaloriesExceeded();
            }

            int stepsRec;
            if (!int.TryParse(stepsNumTextBox.Text, out stepsRec) || stepsRec <= 0)
            {//error handling for when user input is invalid.
                MessageBox.Show("Invalid input. Please enter a valid integer greater than 0.");
                return;
            }

            for (int i = 0; i < stepsRec; i++)
            {
                string step = Microsoft.VisualBasic.Interaction.InputBox("Enter each step:");
                stepsList.Add(step);
            }
            //calls display and sorting methods
            DisplayRecipe();
            SortRecipe();

            // Clear the input fields
            ingredientsNumTextBox.Clear();
            stepsNumTextBox.Clear();
        }

        private void DisplayRecipe()
        {
            // Display the recipe details to the user in the GUI

            recipeListBox.Items.Clear();
            recipeListBox.Items.Add("Ingredients:");

            for (int i = 0; i < ingredientsNum; i++)
            {
                string ingredient = $"{nameIngrList[i]} - {quantityIngredientsList[i]} {unitOfMeasurementList[i]}";
                recipeListBox.Items.Add(ingredient);
            }

            recipeListBox.Items.Add("Steps:");

            for (int i = 0; i < stepsList.Count; i++)
            {
                recipeListBox.Items.Add($"{i + 1}. {stepsList[i]}");
            }
        }

        private int TotalCaloriesCalculation(List<int> caloriesList)
        {
            // Calculates and return the total caloriesconatined by the recipe.

            int sum = 0;
            foreach (int calories in caloriesList)
            {
                sum += calories;
            }
            return sum;
        }

        private void CaloriesExceeded()
        {
            // Handles the event when the calories exceed the limit,which is 300 calories.

            MessageBox.Show("Total calories for the recipe exceed 300!");
        }

        private void SortRecipe()
        {
            // Sort the recipe ingredients alphabetically

            nameIngrList.Sort();
            DisplayRecipe();
        }

        private void resetQuantityButton_Click(object sender, RoutedEventArgs e)
        {
            // Reset the quantities of the recipe ingredients

            quantityIngredientstwo = new List<int>(quantityIngredientsList);

            for (int i = 0; i < ingredientsNum; i++)
            {
                recipeListBox.Items[i + 1] = $"{nameIngrList[i]} - {quantityIngredientstwo[i]} {unitOfMeasurementList[i]}";
            }
        }

        private void clearRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            // Clear the recipe details

            ingredientsNumTextBox.Clear();
            stepsNumTextBox.Clear();
            nameIngrList.Clear();
            quantityIngredientsList.Clear();
            unitOfMeasurementList.Clear();
            stepsList.Clear();
            calorieslist.Clear();
            foodgroupList.Clear();
            recipeListBox.Items.Clear();
        }

        private void AddStepButton_Click(object sender, RoutedEventArgs e)
        {
            // Handle the click event of the AddStepButton
            string step = Microsoft.VisualBasic.Interaction.InputBox("Enter a new step:");
            stepsList.Add(step);
            DisplayRecipe();
        }

        private void ResetQuantitiesButton_Click(object sender, RoutedEventArgs e)
        {

        }
        private void SortRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            // Handle the click event of the SortRecipeButton
            SortRecipe();
        }
        private void FilterButton_Click(object sender, RoutedEventArgs e)
        {
            // Handle the click event of the FilterButton
            string ingredientName = ingredientFilterTextBox.Text.Trim();
            string foodGroup = foodGroupComboBox.SelectedValue?.ToString();
            int maxCalories;

            if (!int.TryParse(maxCaloriesTextBox.Text, out maxCalories))
            {
                MessageBox.Show("Invalid input. Please enter a valid integer.");
                return;
            }

            // Apply the filters and display the filtered recipe
            List<string> filteredRecipe = GetFilteredRecipe(ingredientName, foodGroup, maxCalories);
            DisplayFilteredRecipe(filteredRecipe);
        }

        private List<string> GetFilteredRecipe(string ingredientName, string foodGroup, int maxCalories)
        {
            // Apply the filters to the recipe and return the filtered result

            List<string> filteredRecipe = new List<string>();

            for (int i = 0; i < nameRecipeList.Count; i++)
            {
                if ((!string.IsNullOrWhiteSpace(ingredientName) && nameIngrList[i].Contains(ingredientName)) ||
                    (!string.IsNullOrWhiteSpace(foodGroup) && foodgroupList[i] == foodGroup) ||
                    (calorieslist[i] <= maxCalories))
                {
                    filteredRecipe.Add(nameRecipeList[i]);
                }
            }

            return filteredRecipe;
        }

        private void DisplayFilteredRecipe(List<string> filteredRecipe)
        {
            // Displays the filtered recipe to the user

            recipeListBox.Items.Clear();
            recipeListBox.Items.Add("Filtered Recipe:");

            foreach (string recipe in filteredRecipe)
            {
                recipeListBox.Items.Add(recipe);
            }
        }
        //GETS NUMBER OF INGREDIENTS
        private void ingredientsNumTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }


    }
}
    

